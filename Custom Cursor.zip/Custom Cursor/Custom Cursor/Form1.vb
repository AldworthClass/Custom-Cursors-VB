﻿Public Class frmCursor
    Dim flame_cursor As IO.MemoryStream     'Use .cur file


    Dim prevCursor As Cursor    'We will save the previous state of the cursor in this variable when we want to remember it.
    Private Sub btnBuiltIn_Click(sender As Object, e As EventArgs) Handles btnBuiltIn.Click
        Me.Cursor = Cursors.Cross
    End Sub

    Private Sub btnDefaultCursor_Click(sender As Object, e As EventArgs) Handles btnDefaultCursor.Click
        Me.Cursor = Cursors.Default

    End Sub

    Private Sub imgTarget_MouseEnter(sender As Object, e As EventArgs) Handles imgTarget.MouseEnter
        prevCursor = Me.Cursor  'We want to remember what the cursor was before we change it so that we can go back to it when the mouse leaves the PictureBox
        Me.Cursor = Cursors.Hand
    End Sub

    Private Sub imgTarget_MouseLeave(sender As Object, e As EventArgs) Handles imgTarget.MouseLeave
        Me.Cursor = prevCursor
    End Sub

    Private Sub btnCustomMadeCursor_Click(sender As Object, e As EventArgs) Handles btnCustomMadeCursor.Click
        flame_cursor = New IO.MemoryStream(My.Resources.cursor) 'Turns cursor into a Stream
        Me.Cursor = New Cursor(flame_cursor)    'Sets the Cursor
    End Sub



    Private Sub ratTarget_CheckedChanged(sender As Object, e As EventArgs) Handles ratTarget.CheckedChanged
        Me.Cursor = New Cursor(My.Resources.crosshair.GetHicon)
    End Sub

    Private Sub radSwordCenter_CheckedChanged(sender As Object, e As EventArgs) Handles radSwordCenter.CheckedChanged
        Me.Cursor = New Cursor(My.Resources.swordCenterClick.GetHicon)
    End Sub

    Private Sub radCornerHitpoint_CheckedChanged(sender As Object, e As EventArgs) Handles radCornerHitpoint.CheckedChanged
        Me.Cursor = New Cursor(My.Resources.swordTipClick.GetHicon)
    End Sub
End Class
