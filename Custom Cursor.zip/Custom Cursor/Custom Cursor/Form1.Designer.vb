﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCursor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCursor))
        Me.btnDefaultCursor = New System.Windows.Forms.Button()
        Me.btnCustomMadeCursor = New System.Windows.Forms.Button()
        Me.imgTarget = New System.Windows.Forms.PictureBox()
        Me.btnBuiltIn = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ratTarget = New System.Windows.Forms.RadioButton()
        Me.radSwordCenter = New System.Windows.Forms.RadioButton()
        Me.radCornerHitpoint = New System.Windows.Forms.RadioButton()
        CType(Me.imgTarget, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnDefaultCursor
        '
        Me.btnDefaultCursor.Location = New System.Drawing.Point(12, 12)
        Me.btnDefaultCursor.Name = "btnDefaultCursor"
        Me.btnDefaultCursor.Size = New System.Drawing.Size(75, 23)
        Me.btnDefaultCursor.TabIndex = 1
        Me.btnDefaultCursor.Text = "Default Cursor"
        Me.btnDefaultCursor.UseVisualStyleBackColor = True
        '
        'btnCustomMadeCursor
        '
        Me.btnCustomMadeCursor.Location = New System.Drawing.Point(93, 11)
        Me.btnCustomMadeCursor.Name = "btnCustomMadeCursor"
        Me.btnCustomMadeCursor.Size = New System.Drawing.Size(75, 50)
        Me.btnCustomMadeCursor.TabIndex = 2
        Me.btnCustomMadeCursor.Text = "Custom Cursor"
        Me.btnCustomMadeCursor.UseVisualStyleBackColor = True
        '
        'imgTarget
        '
        Me.imgTarget.Image = CType(resources.GetObject("imgTarget.Image"), System.Drawing.Image)
        Me.imgTarget.Location = New System.Drawing.Point(12, 74)
        Me.imgTarget.Name = "imgTarget"
        Me.imgTarget.Size = New System.Drawing.Size(156, 126)
        Me.imgTarget.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgTarget.TabIndex = 3
        Me.imgTarget.TabStop = False
        '
        'btnBuiltIn
        '
        Me.btnBuiltIn.Location = New System.Drawing.Point(12, 41)
        Me.btnBuiltIn.Name = "btnBuiltIn"
        Me.btnBuiltIn.Size = New System.Drawing.Size(75, 20)
        Me.btnBuiltIn.TabIndex = 4
        Me.btnBuiltIn.Text = "Built In Cursor"
        Me.btnBuiltIn.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radCornerHitpoint)
        Me.GroupBox1.Controls.Add(Me.radSwordCenter)
        Me.GroupBox1.Controls.Add(Me.ratTarget)
        Me.GroupBox1.Location = New System.Drawing.Point(174, 11)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(161, 101)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Custom Cursors Using Images"
        '
        'ratTarget
        '
        Me.ratTarget.AutoSize = True
        Me.ratTarget.Location = New System.Drawing.Point(7, 20)
        Me.ratTarget.Name = "ratTarget"
        Me.ratTarget.Size = New System.Drawing.Size(104, 17)
        Me.ratTarget.TabIndex = 0
        Me.ratTarget.TabStop = True
        Me.ratTarget.Text = "Center Hitpoint 1"
        Me.ratTarget.UseVisualStyleBackColor = True
        '
        'radSwordCenter
        '
        Me.radSwordCenter.AutoSize = True
        Me.radSwordCenter.Location = New System.Drawing.Point(7, 43)
        Me.radSwordCenter.Name = "radSwordCenter"
        Me.radSwordCenter.Size = New System.Drawing.Size(128, 17)
        Me.radSwordCenter.TabIndex = 1
        Me.radSwordCenter.TabStop = True
        Me.radSwordCenter.Text = "Sword Center Hitpoint"
        Me.radSwordCenter.UseVisualStyleBackColor = True
        '
        'radCornerHitpoint
        '
        Me.radCornerHitpoint.AutoSize = True
        Me.radCornerHitpoint.Location = New System.Drawing.Point(7, 66)
        Me.radCornerHitpoint.Name = "radCornerHitpoint"
        Me.radCornerHitpoint.Size = New System.Drawing.Size(115, 17)
        Me.radCornerHitpoint.TabIndex = 2
        Me.radCornerHitpoint.TabStop = True
        Me.radCornerHitpoint.Text = "Sword Left Hitpoint"
        Me.radCornerHitpoint.UseVisualStyleBackColor = True
        '
        'frmCursor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(364, 212)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnBuiltIn)
        Me.Controls.Add(Me.imgTarget)
        Me.Controls.Add(Me.btnCustomMadeCursor)
        Me.Controls.Add(Me.btnDefaultCursor)
        Me.Name = "frmCursor"
        Me.Text = "Custom Cursors"
        CType(Me.imgTarget, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDefaultCursor As Button
    Friend WithEvents btnCustomMadeCursor As Button
    Friend WithEvents imgTarget As PictureBox
    Friend WithEvents btnBuiltIn As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radCornerHitpoint As RadioButton
    Friend WithEvents radSwordCenter As RadioButton
    Friend WithEvents ratTarget As RadioButton
End Class
